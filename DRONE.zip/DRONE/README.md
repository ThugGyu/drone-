# 🚁 DRONE Control System

An advanced quadcopter control system with multiple interfaces and safety features.

## 🚀 Quick Start

### Option 1: Use Main Launcher (Recommended)
```bash
# Double-click or run:
START_DRONE_SYSTEM.bat
```

### Option 2: Manual Steps
```bash
1. Run: 1_start_system.bat        # Start Gazebo + ROS2
2. Run: 2_takeoff.bat            # Takeoff drone
3. Choose control method:
   - 3_keyboard_control.bat      # Menu-based control
   - 5_advanced_teleop.bat       # Real-time control
   - 6_gui_teleop_en.bat         # GUI control (Recommended)
4. Run: 4_landing.bat            # Land drone when done
```

## 📁 Project Structure

```
DRONE/
├── 🚀 system/              # System startup and shutdown
│   ├── start_system.bat        # Start Gazebo + ROS2
│   ├── takeoff.bat             # Drone takeoff
│   ├── landing.bat             # Drone landing
│   └── start_gui_system.bat    # Complete system startup
│
├── 🎮 control/             # Control interfaces
│   ├── keyboard_control.bat    # Menu-based keyboard control
│   ├── advanced_teleop.bat     # Real-time teleoperation
│   ├── gui_teleop.bat          # GUI control system
│   └── gui_teleop_korean.bat   # GUI control (Korean)
│
├── 🔧 utils/               # Utilities and tools
│   ├── check_requirements.bat  # Check system requirements
│   ├── setup_x11.bat          # Setup X11 display
│   └── setup_path_fix.bat     # Fix Korean path issues
│
├── 📚 docs/                # Documentation
│   ├── README_Usage_Guide.txt  # Detailed usage guide
│   └── GUI_Manual.txt          # GUI system manual
│
├── 🐍 scripts/             # Python scripts
│   ├── gui_teleop_control.py          # Main GUI control (English)
│   ├── gui_teleop_control_korean.py   # GUI control (Korean)
│   ├── advanced_teleop_control.py     # Advanced teleoperation
│   └── check_gui_requirements.py     # Requirements checker
│
├── ⚙️ config/              # Configuration files
│   └── drone_visualization.rviz       # RViz configuration
│
├── 🗺️ maps/                # Map files
│   ├── drone_arena.pgm            # Arena map image
│   ├── drone_arena.yaml           # Arena map config
│   └── drone_arena_preview.txt    # Map preview
│
├── 🤖 models/              # Trained AI models
│   ├── ppo_gpu_drone_final.zip
│   ├── improved_drone_final.zip
│   └── ppo_campus_drone_final.zip
│
├── 🚀 launch/              # ROS2 launch files
│   ├── full_system.launch.py
│   ├── full_system_rviz.launch.py
│   └── city_demo.launch.py
│
├── 📝 logs/                # Training and operation logs
│   └── ppo_drone_*                # PPO training logs
│
├── 🔨 build/               # ROS2 build output
├── 📦 install/             # ROS2 install output
├── package.xml             # ROS2 package configuration
├── CMakeLists.txt          # ROS2 build configuration
└── START_DRONE_SYSTEM.bat  # 🎯 Main launcher script
```

## 🎮 Control Methods

### 1. 📱 Menu-based Control
- **File**: `control/keyboard_control.bat`
- **Features**: Simple menu selection, step-by-step commands
- **Best for**: Beginners, testing individual movements

### 2. ⌨️ Real-time Control
- **File**: `control/advanced_teleop.bat`
- **Features**: WASD movement, real-time response, 5 speed levels
- **Best for**: Experienced users, precise control

### 3. 🖥️ GUI Control (Recommended)
- **File**: `control/gui_teleop.bat`
- **Features**: 
  - Graphical interface with real-time map
  - Mouse click navigation
  - Automatic missions (square, circle, patrol)
  - Safety features and monitoring
  - Multiple input methods (mouse, keyboard, buttons)
- **Best for**: All users, comprehensive control

## 🛡️ Safety Features

- **Altitude limits**: 0.3m - 15.0m
- **Distance limits**: 20m from home position
- **Emergency landing**: X key or emergency button
- **Automatic boundary checking**
- **Real-time status monitoring**

## 🔧 System Requirements

- **OS**: Windows 10/11 with WSL2
- **ROS2**: Humble (in WSL)
- **Display**: X11 server (WSLg, VcXsrv, or X410)
- **Python**: 3.8+ with required packages
- **Gazebo**: Garden or newer

## 🆘 Troubleshooting

### Common Issues:
1. **GUI won't open**: Run `utils/setup_x11.bat`
2. **Korean path issues**: Run `utils/setup_path_fix.bat`
3. **Missing requirements**: Run `utils/check_requirements.bat`
4. **No drone response**: Check if system started properly

### Quick Fixes:
- Restart WSL: `wsl --shutdown` then restart
- Check display: `echo $DISPLAY` should show `:0`
- Verify ROS2: `ros2 topic list` should show topics

## 🌟 Features

- ✅ **Multiple control interfaces** (Menu, Real-time, GUI)
- ✅ **Real-time 2D map visualization**
- ✅ **Automatic mission planning**
- ✅ **Safety systems and limits**
- ✅ **Multi-language support** (English/Korean)
- ✅ **Path issue resolution**
- ✅ **Comprehensive documentation**

## 📞 Support

- Check `docs/` folder for detailed manuals
- Use `START_DRONE_SYSTEM.bat` for guided setup
- Run utilities in `utils/` folder for troubleshooting

---

🎉 **Happy Flying!** 🚁✨ 